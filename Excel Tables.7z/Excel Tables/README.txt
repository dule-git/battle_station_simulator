U svakom folderu se nalazi posebna putanja nekog neprijatelja u nekom okruženju.

Jedan folder obuhvata:
	1. Animation.kml file koji prikazuje kretanje neprijatelja
	2. Grafik na kom se vide tražene vrednosti (ugao, brzina, ubrzanje)
	3. Excel tabela na koja sadrži vrednosti iz grafika

Tipovi neprijatelja po folderima su:
	Bora Bora Islands - Vehicle
	Botswana Desert - Vehicle
	Canadian Mountains - Helicopter
	Libian Desert - Soldier
	Siberian Sea - Boat